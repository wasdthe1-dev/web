// server/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { OAuth2Client } = require('google-auth-library');
const nodemailer = require('nodemailer');
const cookieParser = require('cookie-parser');

const app = express();
const PORT = process.env.PORT || 4000;
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const CONTACT_RECEIVER = process.env.CONTACT_RECEIVER || '11715@jaipuria.com';
const path = require('path');

const client = new OAuth2Client(GOOGLE_CLIENT_ID);

// middleware
app.use(cors({ 
  origin: '*', 
  credentials: false,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Utility: create nodemailer transporter if SMTP configured
function createTransporter() {
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: (process.env.SMTP_SECURE === 'true'), // true for 465, false for other ports
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
  }
  return null;
}

const transporter = createTransporter();
const fs = require('fs');

// Persistent user database using JSON file
const DB_FILE = path.join(__dirname, 'users.json');

// Load users from file
function loadUsers() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      const users = JSON.parse(data);
      console.log(`✓ Loaded ${Object.keys(users).length} users from database`);
      return new Map(Object.entries(users));
    }
  } catch (err) {
    console.error('Error loading users:', err.message);
  }
  return new Map();
}

// Save users to file
function saveUsers(userDatabase) {
  try {
    const users = Object.fromEntries(userDatabase);
    fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2), 'utf8');
    console.log('✓ Users saved to database');
  } catch (err) {
    console.error('Error saving users:', err.message);
  }
}

// Initialize user database
const userDatabase = loadUsers();

// Ticket database
const TICKETS_FILE = path.join(__dirname, 'tickets.json');

// Load tickets from file
function loadTickets() {
  try {
    if (fs.existsSync(TICKETS_FILE)) {
      const data = fs.readFileSync(TICKETS_FILE, 'utf8');
      const tickets = JSON.parse(data);
      console.log(`✓ Loaded ${tickets.length} tickets from database`);
      return tickets;
    }
  } catch (err) {
    console.error('Error loading tickets:', err.message);
  }
  return [];
}

// Save tickets to file
function saveTickets(tickets) {
  try {
    fs.writeFileSync(TICKETS_FILE, JSON.stringify(tickets, null, 2), 'utf8');
    console.log('✓ Tickets saved to database');
  } catch (err) {
    console.error('Error saving tickets:', err.message);
  }
}

// Initialize tickets database
let ticketsDatabase = loadTickets();

// Endpoint: verify Google ID token
app.post('/api/auth/google', async (req, res) => {
  // Set JSON content type explicitly
  res.setHeader('Content-Type', 'application/json');
  
  try {
    console.log('📥 Received auth request');
    console.log('  - Body:', req.body);
    console.log('  - Headers:', req.headers);
    
    const { id_token } = req.body;
    
    if (!GOOGLE_CLIENT_ID) {
      console.error('✗ GOOGLE_CLIENT_ID not configured in .env');
      return res.status(500).json({ error: 'Server not configured for Google login' });
    }
    
    if (!id_token) {
      console.warn('⚠ Google auth: Missing id_token');
      return res.status(400).json({ error: 'Missing id_token' });
    }

    console.log('🔐 Verifying Google token...');
    
    const ticket = await client.verifyIdToken({
      idToken: id_token,
      audience: GOOGLE_CLIENT_ID
    });

    const payload = ticket.getPayload();
    const userId = payload.sub;
    
    console.log('✓ Token verified for user:', payload.email);
    
    // Check if user exists in database
    const isNewUser = !userDatabase.has(userId);
    
    if (isNewUser) {
      // Store new user with 5 starting tokens
      userDatabase.set(userId, {
        id: userId,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
        tokens: 5,
        accountComplete: false,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString()
      });
      saveUsers(userDatabase);
      console.log('✓ New user registered:', payload.email, '- Starting tokens: 5');
    } else {
      // Update last login for existing user
      const user = userDatabase.get(userId);
      user.lastLogin = new Date().toISOString();
      userDatabase.set(userId, user);
      saveUsers(userDatabase);
      console.log('✓ Returning user logged in:', payload.email);
    }
    
    // Get user data from database
    const userData = userDatabase.get(userId);
    
    // Prepare response
    const responseData = {
      ok: true,
      isNewUser: isNewUser,
      accountComplete: userData.accountComplete || false,
      user: {
        id: userId,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
        tokens: userData.tokens || 5,
        displayName: userData.displayName || null,
        phone: userData.phone || null,
        bio: userData.bio || null
      }
    };
    
    console.log('📤 Sending response:', responseData);
    
    // Return response with user info and new user flag
    return res.status(200).json(responseData);
  } catch (err) {
    console.error('✗ Google token verification error:', err?.message || err);
    console.error('  - Stack:', err?.stack);
    return res.status(401).json({ error: 'Invalid ID token: ' + (err?.message || 'verification failed') });
  }
});

// Endpoint: update user profile (for settings page)
app.post('/api/user/update-profile', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { userId, displayName, phone, bio, picture } = req.body;
    
    console.log('📝 Profile update request for user:', userId);
    
    if (!userId) {
      return res.status(400).json({ error: 'Missing userId' });
    }
    
    const user = userDatabase.get(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update user profile
    if (displayName) user.displayName = displayName;
    if (phone !== undefined) user.phone = phone;
    if (bio !== undefined) user.bio = bio;
    if (picture) user.picture = picture;
    user.updatedAt = new Date().toISOString();
    
    userDatabase.set(userId, user);
    saveUsers(userDatabase);
    
    console.log('✓ Profile updated for:', user.email);
    
    return res.status(200).json({
      ok: true,
      message: 'Profile updated successfully',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        picture: user.picture,
        displayName: user.displayName,
        phone: user.phone,
        bio: user.bio,
        tokens: user.tokens,
        accountComplete: user.accountComplete
      }
    });
  } catch (err) {
    console.error('✗ Profile update error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Endpoint: update user profile after account creation
app.post('/api/user/complete-profile', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { userId, displayName, phone, bio } = req.body;
    
    console.log('📝 Profile completion request for user:', userId);
    
    if (!userId) {
      return res.status(400).json({ error: 'Missing userId' });
    }
    
    const user = userDatabase.get(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update user profile
    user.displayName = displayName || user.name;
    user.phone = phone || null;
    user.bio = bio || null;
    user.accountComplete = true;
    user.profileCompletedAt = new Date().toISOString();
    
    userDatabase.set(userId, user);
    saveUsers(userDatabase);
    
    console.log('✓ Profile completed for:', user.email);
    
    return res.status(200).json({
      ok: true,
      message: 'Profile completed successfully',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        picture: user.picture,
        displayName: user.displayName,
        phone: user.phone,
        bio: user.bio,
        tokens: user.tokens,
        accountComplete: user.accountComplete
      }
    });
  } catch (err) {
    console.error('✗ Profile completion error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to complete profile' });
  }
});

// Endpoint: create ticket
app.post('/api/tickets/create', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { userId, title, description, timeRequired, location, needExtraPeople, extraPeopleCount, totalCost } = req.body;
    
    console.log('🎫 Ticket creation request from user:', userId);
    
    if (!userId || !title || !description || !timeRequired || !location) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    const user = userDatabase.get(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if user has enough tokens
    if (user.tokens < totalCost) {
      return res.status(400).json({ error: 'Insufficient tokens' });
    }
    
    // Create ticket
    const ticket = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      userId,
      title,
      description,
      timeRequired,
      location,
      needExtraPeople,
      extraPeopleCount: extraPeopleCount || 0,
      totalCost,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Deduct tokens from user
    user.tokens -= totalCost;
    userDatabase.set(userId, user);
    saveUsers(userDatabase);
    
    // Save ticket
    ticketsDatabase.push(ticket);
    saveTickets(ticketsDatabase);
    
    console.log('✓ Ticket created:', ticket.id);
    
    return res.status(200).json({
      ok: true,
      message: 'Ticket created successfully',
      ticket,
      remainingTokens: user.tokens
    });
  } catch (err) {
    console.error('✗ Ticket creation error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to create ticket' });
  }
});

// Endpoint: get all tickets (for browse page)
app.get('/api/tickets/all', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    // Return all tickets, sorted by creation date (newest first)
    const allTickets = [...ticketsDatabase].sort((a, b) => 
      new Date(b.createdAt) - new Date(a.createdAt)
    );
    
    return res.status(200).json({
      ok: true,
      tickets: allTickets
    });
  } catch (err) {
    console.error('✗ Error fetching all tickets:', err?.message || err);
    return res.status(500).json({ error: 'Failed to fetch tickets' });
  }
});

// Endpoint: get user tickets
app.get('/api/tickets/user/:userId', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { userId } = req.params;
    
    const userTickets = ticketsDatabase.filter(t => t.userId === userId);
    
    // Sort by creation date (newest first)
    userTickets.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    return res.status(200).json({
      ok: true,
      tickets: userTickets
    });
  } catch (err) {
    console.error('✗ Error fetching tickets:', err?.message || err);
    return res.status(500).json({ error: 'Failed to fetch tickets' });
  }
});

// Endpoint: get ticket by ID
app.get('/api/tickets/:ticketId', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { ticketId } = req.params;
    
    const ticket = ticketsDatabase.find(t => t.id === ticketId);
    
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    return res.status(200).json({
      ok: true,
      ticket
    });
  } catch (err) {
    console.error('✗ Error fetching ticket:', err?.message || err);
    return res.status(500).json({ error: 'Failed to fetch ticket' });
  }
});

// Endpoint: update ticket status
app.post('/api/tickets/:ticketId/update-status', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { ticketId } = req.params;
    const { userId, status } = req.body;
    
    // Validate status
    const validStatuses = ['open', 'in-progress', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const ticketIndex = ticketsDatabase.findIndex(t => t.id === ticketId);
    
    if (ticketIndex === -1) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    const ticket = ticketsDatabase[ticketIndex];
    
    // Check if user owns the ticket
    if (ticket.userId !== userId) {
      return res.status(403).json({ error: 'Not authorized to update this ticket' });
    }
    
    // Validate status transitions
    if (ticket.status === 'completed' || ticket.status === 'cancelled') {
      return res.status(400).json({ error: 'Cannot update completed or cancelled tickets' });
    }
    
    if (status === 'completed' && ticket.status !== 'in-progress') {
      return res.status(400).json({ error: 'Ticket must be in progress before marking as completed' });
    }
    
    // Update ticket status
    ticket.status = status;
    ticket.updatedAt = new Date().toISOString();
    
    if (status === 'completed') {
      ticket.completedAt = new Date().toISOString();
    }
    
    ticketsDatabase[ticketIndex] = ticket;
    saveTickets(ticketsDatabase);
    
    console.log('✓ Ticket status updated:', ticketId, 'to', status);
    
    return res.status(200).json({
      ok: true,
      message: 'Ticket status updated successfully',
      ticket
    });
  } catch (err) {
    console.error('✗ Ticket status update error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to update ticket status' });
  }
});

// Endpoint: cancel ticket
app.post('/api/tickets/:ticketId/cancel', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { ticketId } = req.params;
    const { userId } = req.body;
    
    const ticketIndex = ticketsDatabase.findIndex(t => t.id === ticketId);
    
    if (ticketIndex === -1) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    const ticket = ticketsDatabase[ticketIndex];
    
    // Check if user owns the ticket
    if (ticket.userId !== userId) {
      return res.status(403).json({ error: 'Not authorized to cancel this ticket' });
    }
    
    // Check if ticket can be cancelled
    if (ticket.status !== 'open') {
      return res.status(400).json({ error: 'Only open tickets can be cancelled' });
    }
    
    // Refund tokens to user
    const user = userDatabase.get(userId);
    if (user) {
      user.tokens += ticket.totalCost;
      userDatabase.set(userId, user);
      saveUsers(userDatabase);
    }
    
    // Update ticket status
    ticket.status = 'cancelled';
    ticket.updatedAt = new Date().toISOString();
    ticketsDatabase[ticketIndex] = ticket;
    saveTickets(ticketsDatabase);
    
    console.log('✓ Ticket cancelled:', ticketId);
    
    return res.status(200).json({
      ok: true,
      message: 'Ticket cancelled successfully',
      ticket,
      remainingTokens: user.tokens
    });
  } catch (err) {
    console.error('✗ Ticket cancellation error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to cancel ticket' });
  }
});

// Endpoint: contact form — server sends email using nodemailer (SMTP)
app.post('/api/contact', async (req, res) => {
  try {
    const { email, message } = req.body;
    
    console.log('Contact request received:', { email, messageLength: message?.length });
    
    if (!email || !message) {
      return res.status(400).json({ error: 'Missing email or message' });
    }

    const mailOptions = {
      from: `"TokenHelp Contact" <${process.env.SMTP_USER || 'no-reply@tokenhelp.app'}>`,
      to: CONTACT_RECEIVER,
      subject: `TokenHelp contact from ${email}`,
      text: `Message from: ${email}\n\n${message}`,
      replyTo: email
    };

    if (transporter) {
      try {
        const info = await transporter.sendMail(mailOptions);
        console.log('✓ Contact email sent successfully:', info.messageId);
        return res.status(200).json({ 
          ok: true, 
          message: 'Message sent successfully! We will get back to you soon.' 
        });
      } catch (emailErr) {
        console.error('✗ Nodemailer error:', emailErr?.message || emailErr);
        console.log('=== CONTACT MESSAGE (email failed to send) ===');
        console.log(mailOptions);
        console.log('Error:', emailErr?.message);
        console.log('=== END CONTACT MESSAGE ===');
        return res.status(500).json({ error: 'Email service temporarily unavailable. Please try again later.' });
      }
    } else {
      // fallback: log to server console
      console.log('⚠ SMTP not configured - logging message to server console');
      console.log('=== CONTACT MESSAGE (no SMTP configured) ===');
      console.log(mailOptions);
      console.log('=== END CONTACT MESSAGE ===');
      return res.status(200).json({ 
        ok: true, 
        message: 'Message received! (Email service not configured on server)' 
      });
    }
  } catch (err) {
    console.error('✗ Contact endpoint error:', err?.message || err);
    return res.status(500).json({ error: 'Failed to process request. Please try again later.' });
  }
});

// Static files (AFTER API routes)
const publicPath = path.join(__dirname, '..', 'public');
console.log('📁 Serving static files from:', publicPath);
app.use(express.static(publicPath));

// SPA fallback - must be AFTER all API routes and static files
// Only catch GET requests to avoid interfering with API
app.get('*', (req, res, next) => {
  // Don't catch API routes
  if (req.path.startsWith('/api/')) {
    return next();
  }
  
  const indexPath = path.join(__dirname, '..', 'public', 'index.html');
  res.sendFile(indexPath);
});

app.listen(PORT, () => {
  console.log(`✓ Server listening on port ${PORT}`);
  console.log(`✓ Google Client ID configured: ${GOOGLE_CLIENT_ID ? 'Yes' : 'No'}`);
});
